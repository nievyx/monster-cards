import os
import random

import pygame

from src.game import Monster

PLAYER_LOG_COLOR = None
ENEMY_LOG_COLOR = (240, 80, 16)
# Note: theme/theme.py replacing this in future implementation


class Config:
    SCREEN_WIDTH = 1200
    SCREEN_HEIGHT = 850

    game_title = "Niamh's Monster Cards"

    ALLOW_OVERHEAL = False

    num_players = 2
    cards_per_player = [5, 3]
    enemy_action_delay = 600

    RARITY_WEIGHTS = {
        'common': 10,
        'uncommon':6,
        'rare':4,
        'epic':1,
        'legendary':0.5,
    }

    @staticmethod
    def load_game_data():
        """
        Loads all game content via import side effects.
        Registers monsters and spells in global pools.
        NOTE: Imports may appear to be unused in some IDEs, but
        is required.
        """
        import src.content.monster_data
        import src.content.spell_data

    @staticmethod
    def load_random_background(screen_size):
        folder = 'src/assets/backgrounds/'
        img_types = ('.png', '.jpg', '.jpeg', '.webp')

        files = [
            os.path.join(folder, name)
            for name in os.listdir(folder)
            if name.lower().endswith(img_types)
        ]
        bg_img = random.choice(files)

        image = pygame.image.load(bg_img).convert()
        image = pygame.transform.scale(image, screen_size)

        return image

    def create_players(self):
        players = {}

        for i in range(self.num_players):
            players[i] = Monster.generate_rand_team(
                size=self.cards_per_player[i],
                rarity_weights=self.RARITY_WEIGHTS
            )
        return players


    def create_enemy_team(self, wave=1):
        """ Recreates enemy team """
        base_enemy_cards = self.cards_per_player[1]

        # increase slowly with wave
        enemy_size = min(5, base_enemy_cards + (wave - 1) // 2)

        return Monster.generate_rand_team(
            size=enemy_size,
            rarity_weights=self.RARITY_WEIGHTS
        )

    def get_new_card(self):
        """ Recreates enemy team"""
        return Monster.generate_rand_monster(rarity_weights=self.RARITY_WEIGHTS)





