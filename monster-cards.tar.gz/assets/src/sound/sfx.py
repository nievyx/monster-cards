import os

import sys

IS_BROWSER = sys.platform == "emscripten"

import pygame

class SFX:
    def __init__(self, base_path='src/assets/sfx'):
        pygame.mixer.init()
        self.base_path = base_path
        self.cache = {}

        self.volume = 0.5
        self.set_volume(self.volume)

    def handle_error(self):
        pass

    def play(self, spell) -> None:
        """Checks for spell and plays sound if available,
        Caches sound if sound is not already loaded"""
        sounds_name = spell.sfx_name

        if IS_BROWSER:
            MUSIC_EXTENTSION = '.ogg'
        else:
            MUSIC_EXTENTSION = '.wav'


        sound_path = os.path.join(self.base_path, 'spells',f'{sounds_name}{MUSIC_EXTENTSION}')
        print(sound_path) #TODO: delete sound work

        if not os.path.exists(sound_path):
            print(f"[SFX WARNING] Missing sound: {sound_path}")
            return

        if sound_path not in self.cache:
            try:
                sound = pygame.mixer.Sound(sound_path)
                sound.set_volume(self.volume)
                self.cache[sound_path] = sound
            except pygame.error as e:
                print(f"[SFX ERROR:] Sound {sound_path} not found: {e}")

        self.cache[sound_path].play()

    def set_volume(self, volume: float) -> None:
        self.volume = volume
        for sound in self.cache.values():
            sound.set_volume(volume)